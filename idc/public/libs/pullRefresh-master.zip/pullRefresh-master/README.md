pullRefresh
===========

HTML+CSS3+JS实现下拉刷新网页版。

+ 使用[Zepto](https://github.com/madrobby/zepto)
+ 使用[Foundation3 Icon font](http://zurb.com/playground/foundation-icon-fonts-3)
+ CSS3 Animations (no left/top animation)